package br.newtonpaiva.dominio;

import java.util.Objects;

public class Conta {
    private int id;
    private String dataAbertura;
    private String senha;
    private double saldo;
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDataAbertura() {
        return dataAbertura;
    }

    public void setDataAbertura(String dataAbertura) {
        this.dataAbertura = dataAbertura;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }



    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Conta conta = (Conta) o;
        return id == conta.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    public Conta() {
    }

    @Override
    public String toString() {
        return "Conta{" +
                "dataAbertura='" + dataAbertura + '\'' +
                ", senha='" + senha + '\'' +
                '}';
    }

    public Conta(int id, String dataAbertura, String senha, double saldo) {
        this.id = id;
        this.dataAbertura = dataAbertura;
        this.senha = senha;
        this.saldo = saldo;
    }
}
