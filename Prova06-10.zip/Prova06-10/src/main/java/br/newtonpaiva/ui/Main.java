package br.newtonpaiva.ui;

import br.newtonpaiva.dominio.Conta;
import br.newtonpaiva.dominio.Pessoa;

public class Main {
    public static void main(String[] args) {
        var C = new Conta();
        var P = new Pessoa();

        C.setId(2);
        C.setDataAbertura("23/06/2000");
        C.setSenha("1234");
        C.setSaldo(7000.00);

        P.setId(12);
        P.setNome("João");
        P.setTelefone("(11)4002-8922");
        P.setCpf("123.456.789-00");
    }
}
